const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const bgMusic = document.getElementById("bgMusic");

let musicStarted = false;
document.body.addEventListener("click", () => {
  if (!musicStarted) {
    bgMusic.volume = 0.3;
    bgMusic.play();
    musicStarted = true;
  }
});

const background = new Image();
background.src =
  "https://upload.wikimedia.org/wikipedia/commons/1/17/Empty_fighting_ring.png";

const fighters = [
  {
    name: "Li Wei",
    img: "https://chatgpt.com/backend-api/estuary/content?id=file_000000006a4461fa83f02e38405e9ac0&v=0",
    x: 300,
    y: 380,
    left: false,
    keys: { left: "a", right: "d", attack: "q" },
    color: "white",
  },
  {
    name: "El Pingüino",
    img: "https://chatgpt.com/backend-api/estuary/content?id=file_00000000ec0862309969459bfc625f61&v=0",
    x: 900,
    y: 380,
    left: true,
    keys: { left: "ArrowLeft", right: "ArrowRight", attack: "o" },
    color: "gold",
  },
];

fighters.forEach((f) => {
  const image = new Image();
  image.src = f.img;
  f.image = image;
  f.health = 100;
  f.cooldown = false;
  f.attacking = false;
});

let winner = null;

document.addEventListener("keydown", (e) => {
  fighters.forEach((f) => {
    if (e.key === f.keys.left) f.x -= 20;
    if (e.key === f.keys.right) f.x += 20;

    if (e.key === f.keys.attack && !f.cooldown) {
      f.attacking = true;
      f.cooldown = true;
      setTimeout(() => (f.cooldown = false), 700);
      setTimeout(() => (f.attacking = false), 200);

      const enemy = fighters.find((p) => p !== f);
      if (Math.abs(f.x - enemy.x) < 120) {
        enemy.health -= 10;
        if (enemy.health <= 0) {
          winner = f.name;
          bgMusic.pause();
        }
      }
    }
  });
});

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

  fighters.forEach((f) => {
    if (f.image.complete) {
      ctx.save();
      if (f.left) {
        ctx.scale(-1, 1);
        ctx.drawImage(f.image, -f.x - 150, f.y - 200, 150, 200);
      } else {
        ctx.drawImage(f.image, f.x, f.y - 200, 150, 200);
      }
      ctx.restore();

      ctx.fillStyle = "red";
      ctx.fillRect(f.x, f.y - 220, 100, 10);
      ctx.fillStyle = "lime";
      ctx.fillRect(f.x, f.y - 220, f.health, 10);

      if (f.attacking) {
        ctx.strokeStyle = f.color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(f.x + 70, f.y - 100, 50, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  });

  if (winner) {
    ctx.fillStyle = "rgba(0,0,0,0.7)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "white";
    ctx.font = "60px Arial";
    ctx.fillText(`${winner} Wins!`, canvas.width / 2 - 200, canvas.height / 2);
  }

  requestAnimationFrame(draw);
}

draw();
