const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
ctx.fillStyle = 'white';
ctx.font = '24px Arial';
ctx.fillText('Game Loaded Successfully!', 200, 300);
